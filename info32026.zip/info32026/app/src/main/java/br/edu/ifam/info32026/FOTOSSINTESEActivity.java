package br.edu.ifam.info32026;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FOTOSSINTESEActivity extends AppCompatActivity {

    private Button btnVoltar;
    private Button btnProximo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_fotossinteseactivity);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnVoltar = findViewById(R.id.btnVoltar);
        btnProximo = findViewById(R.id.btnProximo);

        // Botão Voltar: Apenas fecha esta tela e volta automaticamente para a GENETICAActivity2
        btnVoltar.setOnClickListener(v -> finish());

        // Botão Próximo: Navega para a ZoologiaActivity2
        btnProximo.setOnClickListener(v -> {
            Intent intent = new Intent(this, ZoologiaActivity2.class);
            startActivity(intent);
        });
    }
}