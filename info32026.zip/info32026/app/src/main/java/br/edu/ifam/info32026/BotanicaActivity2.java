package br.edu.ifam.info32026;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class BotanicaActivity2 extends AppCompatActivity {

    private Button btnVoltar;
    private Button btnFim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_botanica2);

        // Suporte ao modo Edge-to-Edge sem sobrepor barras do sistema
        View mainView = findViewById(R.id.main);
        if (mainView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        // Inicialização dos botões
        btnVoltar = findViewById(R.id.btnVoltar);
        btnFim = findViewById(R.id.btnFim);

        // Ação do botão Voltar (retorna à tela anterior)
        btnVoltar.setOnClickListener(v -> finish());

        // Ação do botão Fim (encerra a Activity)
        btnFim.setOnClickListener(v -> finishAffinity());
    }
}