package br.edu.ifam.info32026;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FotossinteseQuizActivity2 extends AppCompatActivity {

    private ImageButton btnOptionA, btnOptionB, btnOptionC;
    private TextView tvOptionA, tvOptionB, tvOptionC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_fotossintese_quiz2);

        // Configuração para suportar EdgeToEdge
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Mapeamento dos componentes da interface
        btnOptionA = findViewById(R.id.imageButton);
        btnOptionB = findViewById(R.id.imageButton2);
        btnOptionC = findViewById(R.id.imageButton3);

        tvOptionA = findViewById(R.id.edit_text_id);
        tvOptionB = findViewById(R.id.search_edit_frame);
        tvOptionC = findViewById(R.id.open_search_view_edit_text);

        // Configuração dos eventos de clique
        btnOptionA.setOnClickListener(v -> checkAnswer(true, btnOptionA, tvOptionA));
        tvOptionA.setOnClickListener(v -> checkAnswer(true, btnOptionA, tvOptionA));

        btnOptionB.setOnClickListener(v -> checkAnswer(false, btnOptionB, tvOptionB));
        tvOptionB.setOnClickListener(v -> checkAnswer(false, btnOptionB, tvOptionB));

        btnOptionC.setOnClickListener(v -> checkAnswer(false, btnOptionC, tvOptionC));
        tvOptionC.setOnClickListener(v -> checkAnswer(false, btnOptionC, tvOptionC));
    }

    /**
     * Valida se a resposta escolhida está correta.
     *
     * @param isCorrect Se a opção selecionada é a correta.
     * @param selectedBtn Botão da alternativa clicada.
     * @param selectedTv Texto da alternativa clicada.
     */
    private void checkAnswer(boolean isCorrect, ImageButton selectedBtn, TextView selectedTv) {
        // Bloqueia interações após a primeira resposta
        disableOptions();

        if (isCorrect) {
            // Destaque em verde para a resposta correta
            selectedTv.setBackgroundColor(Color.parseColor("#4CAF50"));
            selectedTv.setTextColor(Color.WHITE);
            Toast.makeText(this, "Resposta Correta! O CO2 do ar compõe a maior parte da massa seca.", Toast.LENGTH_LONG).show();
        } else {
            // Destaque em vermelho para a resposta errada
            selectedTv.setBackgroundColor(Color.parseColor("#F44336"));
            selectedTv.setTextColor(Color.WHITE);

            // Destaca a alternativa A (correta) em verde
            tvOptionA.setBackgroundColor(Color.parseColor("#4CAF50"));
            tvOptionA.setTextColor(Color.WHITE);

            Toast.makeText(this, "Resposta Incorreta! A opção correta era a A.", Toast.LENGTH_LONG).show();
        }
        // O clique na alternativa A passa 'true' para indicar que é a resposta certa
        btnOptionA.setOnClickListener(v -> checkAnswer(true, btnOptionA, tvOptionA));
        tvOptionA.setOnClickListener(v -> checkAnswer(true, btnOptionA, tvOptionA));

// As demais passam 'false'
        btnOptionB.setOnClickListener(v -> checkAnswer(false, btnOptionB, tvOptionB));
        btnOptionC.setOnClickListener(v -> checkAnswer(false, btnOptionC, tvOptionC));
    }

    /**
     * Desabilita os cliques em todos os botões e opções.
     */
    private void disableOptions() {
        btnOptionA.setEnabled(false);
        btnOptionB.setEnabled(false);
        btnOptionC.setEnabled(false);

        tvOptionA.setEnabled(false);
        tvOptionB.setEnabled(false);
        tvOptionC.setEnabled(false);
    }
}