package br.edu.ifam.info32026;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import br.edu.ifam.info32026.model.Usuario;
import br.edu.ifam.info32026.model.UsuarioDao;

@Database(entities = {Usuario.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    private static AppDatabase instance;

    public abstract UsuarioDao usuarioDao();

    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "banco_info32026")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }
}
