package br.edu.ifam.info32026;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class QuizActivity2 extends AppCompatActivity {

    private TextView tvQuizTitle;
    private TextView tvQuestion;
    private TextView tvOptionA;
    private TextView tvOptionB;
    private TextView tvOptionC;

    private ImageButton btnOptionA;
    private ImageButton btnOptionB;
    private ImageButton btnOptionC;

    // Controla se a questão já foi respondida para evitar múltiplos cliques
    private boolean isAnswered = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quiz2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            int padding16dp = (int) (16 * getResources().getDisplayMetrics().density);

            v.setPadding(
                    systemBars.left + padding16dp,
                    systemBars.top + padding16dp,
                    systemBars.right + padding16dp,
                    systemBars.bottom + padding16dp
            );
            return insets;
        });

        // Inicialização dos componentes
        tvQuizTitle = findViewById(R.id.tvQuizTitle);
        tvQuestion = findViewById(R.id.tvQuestion);
        tvOptionA = findViewById(R.id.tvOptionA);
        tvOptionB = findViewById(R.id.tvOptionB);
        tvOptionC = findViewById(R.id.tvOptionC);

        btnOptionA = findViewById(R.id.btnOptionA);
        btnOptionB = findViewById(R.id.btnOptionB);
        btnOptionC = findViewById(R.id.btnOptionC);

        // Permite clicar tanto no ImageButton quanto no TextView de cada opção
        btnOptionA.setOnClickListener(v -> checkAnswer("A"));
        tvOptionA.setOnClickListener(v -> checkAnswer("A"));

        btnOptionB.setOnClickListener(v -> checkAnswer("B"));
        tvOptionB.setOnClickListener(v -> checkAnswer("B"));

        btnOptionC.setOnClickListener(v -> checkAnswer("C"));
        tvOptionC.setOnClickListener(v -> checkAnswer("C"));
    }

    /**
     * Valida a resposta:
     * - Opção "A": Resposta CORRETA (Destaca em verde)
     * - Opções "B" e "C": Respostas ERRADAS (Destaca em vermelho e mostra a correta)
     */
    private void checkAnswer(String selectedOption) {
        if (isAnswered) return; // Impede alterar a resposta após selecionar
        isAnswered = true;

        resetSelectionStyles();

        if ("A".equals(selectedOption)) {
            // Opção A (Certa)
            highlightOption("A", "#4CAF50"); // Verde
            Toast.makeText(this, "Resposta Correta! Citologia é o estudo das células.", Toast.LENGTH_LONG).show();
        } else if ("B".equals(selectedOption)) {
            // Opção B (Errada)
            highlightOption("B", "#F44336"); // Vermelho no erro
            highlightOption("A", "#4CAF50"); // Destaca a opção A (correta) em verde
            Toast.makeText(this, "Resposta Incorreta! A opção correta é a letra A.", Toast.LENGTH_LONG).show();
        } else if ("C".equals(selectedOption)) {
            // Opção C (Errada)
            highlightOption("C", "#F44336"); // Vermelho no erro
            highlightOption("A", "#4CAF50"); // Destaca a opção A (correta) em verde
            Toast.makeText(this, "Resposta Incorreta! A opção correta é a letra A.", Toast.LENGTH_LONG).show();
        }

        disableAllButtons();
    }

    /**
     * Altera a cor de fundo do texto selecionado
     */
    private void highlightOption(String option, String colorHex) {
        int color = Color.parseColor(colorHex);
        switch (option) {
            case "A":
                tvOptionA.setBackgroundColor(color);
                tvOptionA.setTextColor(Color.WHITE);
                break;
            case "B":
                tvOptionB.setBackgroundColor(color);
                tvOptionB.setTextColor(Color.WHITE);
                break;
            case "C":
                tvOptionC.setBackgroundColor(color);
                tvOptionC.setTextColor(Color.WHITE);
                break;
        }
    }

    /**
     * Desabilita os botões para evitar novos cliques
     */
    private void disableAllButtons() {
        btnOptionA.setEnabled(false);
        btnOptionB.setEnabled(false);
        btnOptionC.setEnabled(false);
        tvOptionA.setEnabled(false);
        tvOptionB.setEnabled(false);
        tvOptionC.setEnabled(false);
    }

    private void resetSelectionStyles() {
        // Método pronto para ser usado ao carregar a próxima pergunta
    }
}