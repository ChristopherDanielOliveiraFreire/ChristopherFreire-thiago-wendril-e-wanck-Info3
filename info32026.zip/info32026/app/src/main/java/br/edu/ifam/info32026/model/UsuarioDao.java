package br.edu.ifam.info32026.model;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface UsuarioDao {

    @Insert
    void inserir(Usuario usuario);

    @Update
    void atualizar(Usuario usuario);

    @Delete
    void excluir(Usuario usuario);

    @Query("SELECT * FROM usuario WHERE email = :email AND senha = :senha")
    Usuario login(String email, String senha);
}
