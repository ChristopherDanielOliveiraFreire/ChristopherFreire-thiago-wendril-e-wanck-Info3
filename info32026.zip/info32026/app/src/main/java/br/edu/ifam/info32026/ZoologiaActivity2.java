package br.edu.ifam.info32026;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ZoologiaActivity2 extends AppCompatActivity {

    private Button btnVoltar;
    private Button btnProximo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_zoologia2);

        // Suporte Edge-to-Edge sem sobreposição das barras do sistema
        View mainView = findViewById(R.id.main);
        if (mainView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        // Inicialização dos botões conforme os IDs declarados no XML
        btnVoltar = findViewById(R.id.btnVoltar);
        btnProximo = findViewById(R.id.btnProximo);

        // Botão Voltar: Encerra esta Activity e retorna para a tela anterior
        btnVoltar.setOnClickListener(v -> finish());

        // Botão Próximo: Abre a próxima tela (Exemplo: BotanicaActivity2)
        btnProximo.setOnClickListener(v -> {
            Intent intent = new Intent(this, BotanicaActivity2.class);
            startActivity(intent);
        });
    }
}