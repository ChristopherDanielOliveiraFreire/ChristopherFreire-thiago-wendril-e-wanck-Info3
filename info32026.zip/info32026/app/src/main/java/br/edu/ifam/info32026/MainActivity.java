package br.edu.ifam.info32026;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper; // Importante para o Handler moderno
import androidx.appcompat.app.AppCompatActivity;

// Certifique-se de que Projeto2026 seja uma Activity (ex: LoginActivity ou HomeActivity)
import br.edu.ifam.info32026.viewModel.Projeto2026;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Opcional: setContentView(R.layout.activity_main); // Defina seu layout aqui se houver

        // Usando o Looper.getMainLooper() para evitar que o Handler fique obsoleto (deprecated)
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                // Cria a intenção para navegar para a próxima tela
                Intent intent = new Intent(MainActivity.this, Projeto2026.class);
                startActivity(intent);
                finish(); // Fecha a MainActivity para o usuário não voltar a ela pelo botão "Voltar"
            }
        }, 3000); // 3000 milissegundos = 3 segundos
    }
}
