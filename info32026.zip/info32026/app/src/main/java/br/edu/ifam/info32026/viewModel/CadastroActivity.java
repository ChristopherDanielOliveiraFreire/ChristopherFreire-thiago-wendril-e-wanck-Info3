package br.edu.ifam.info32026.viewModel;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.Executors;

import br.edu.ifam.info32026.AppDatabase;
import br.edu.ifam.info32026.Helper.FirebaseHelper;
import br.edu.ifam.info32026.R;
import br.edu.ifam.info32026.model.Usuario;
import br.edu.ifam.info32026.model.UsuarioDao;

public class CadastroActivity extends AppCompatActivity {

    private EditText editNome;
    private EditText editEmail;
    private EditText editSenha;
    private Button botaocadastro;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastro);

        db = AppDatabase.getInstance(this);
        inicializarComponentes();

        botaocadastro.setOnClickListener(v -> validarDados());
    }

    private void inicializarComponentes() {
        // IDs corrigidos de acordo com activity_cadastro.xml
        editNome = findViewById(R.id.edit_text_id);
        editEmail = findViewById(R.id.edit_query);
        editSenha = findViewById(R.id.edge);
        botaocadastro = findViewById(R.id.button2);
    }

    private void validarDados() {
        String nome = editNome.getText().toString().trim();
        String email = editEmail.getText().toString().trim();
        String senha = editSenha.getText().toString().trim();

        if (!nome.isEmpty()) {
            if (!email.isEmpty()) {
                if (!senha.isEmpty()) {
                    Usuario usuario = new Usuario();
                    usuario.setNome(nome);
                    usuario.setEmail(email);
                    usuario.setSenha(senha);

                    cadastrarNoBanco(usuario);
                } else {
                    editSenha.setError("Digite sua senha");
                }
            } else {
                editEmail.setError("Digite seu email");
            }
        } else {
            editNome.setError("Digite seu nome");
        }
    }

    private void cadastrarNoBanco(Usuario usuario) {
        Executors.newSingleThreadExecutor().execute(() -> {
            UsuarioDao dao = db.usuarioDao();
            dao.inserir(usuario);
            runOnUiThread(() -> {
                Toast.makeText(this, "Cadastro realizado com sucesso localmente", Toast.LENGTH_SHORT).show();
                finish();
            });
        });
    }

    private void criaraContaFirebase(Usuario user) {
        FirebaseHelper.getAuth().createUserWithEmailAndPassword(
                user.getEmail(), user.getSenha()
        ).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(this, "Cadastro realizado com sucesso no Firebase", Toast.LENGTH_SHORT).show();
                finish();
                startActivity(new Intent(this, Projeto2026.class));
            } else {
                Toast.makeText(this,
                        "Erro: " + task.getException().getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}
