package br.edu.ifam.info32026;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CitologiaActivity3 extends AppCompatActivity {

    private ImageButton btnOptionA, btnOptionB, btnOptionC;
    private TextView tvOptionA, tvOptionB, tvOptionC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_citologia3);

        // Ajuste dos insets de tela (EdgeToEdge)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Mapeamento dos botões (ImageButtons)
        btnOptionA = findViewById(R.id.imageButton4);
        btnOptionB = findViewById(R.id.imageButton5);
        btnOptionC = findViewById(R.id.imageButton6);

        // Mapeamento dos textos (TextViews)
        tvOptionA = findViewById(R.id.tv_option_a);
        tvOptionB = findViewById(R.id.tv_option_b);
        tvOptionC = findViewById(R.id.tv_option_c);

        // Opção A -> CORRETA (Ribossomos)
        btnOptionA.setOnClickListener(v -> checkAnswer(true, tvOptionA));
        tvOptionA.setOnClickListener(v -> checkAnswer(true, tvOptionA));

        // Opção B -> INCORRETA (Núcleo organizado por carioteca)
        btnOptionB.setOnClickListener(v -> checkAnswer(false, tvOptionB));
        tvOptionB.setOnClickListener(v -> checkAnswer(false, tvOptionB));

        // Opção C -> INCORRETA (Mitocôndrias)
        btnOptionC.setOnClickListener(v -> checkAnswer(false, tvOptionC));
        tvOptionC.setOnClickListener(v -> checkAnswer(false, tvOptionC));
    }

    /**
     * Valida a resposta, exibe feedback visual e Toast correspondente.
     */
    private void checkAnswer(boolean isCorrect, TextView selectedTv) {
        disableOptions();

        if (isCorrect) {
            // Destaca a opção escolhida em verde
            selectedTv.setBackgroundColor(Color.parseColor("#4CAF50"));
            selectedTv.setTextColor(Color.WHITE);
            Toast.makeText(this, "Resposta Correta! Os ribossomos estão presentes em células procariontes e eucariontes.", Toast.LENGTH_LONG).show();
        } else {
            // Destaca a opção incorreta em vermelho
            selectedTv.setBackgroundColor(Color.parseColor("#F44336"));
            selectedTv.setTextColor(Color.WHITE);

            // Destaca a opção A (correta) em verde para orientação
            tvOptionA.setBackgroundColor(Color.parseColor("#4CAF50"));
            tvOptionA.setTextColor(Color.WHITE);

            Toast.makeText(this, "Resposta Incorreta! A opção correta é a A (Ribossomos).", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Bloqueia novas interações após o usuário selecionar uma opção.
     */
    private void disableOptions() {
        btnOptionA.setEnabled(false);
        btnOptionB.setEnabled(false);
        btnOptionC.setEnabled(false);

        tvOptionA.setEnabled(false);
        tvOptionB.setEnabled(false);
        tvOptionC.setEnabled(false);
    }
}