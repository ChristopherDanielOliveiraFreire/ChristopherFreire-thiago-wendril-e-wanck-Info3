package br.edu.ifam.info32026;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class GENETICAActivity2 extends AppCompatActivity {

    private Button btnVoltar;
    private Button btnProximo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        // Verifique se o nome do arquivo XML é "activity_genetica2" ou "activity_geneticaactivity2"
        setContentView(R.layout.activity_geneticaactivity2);

        // Suporte a Edge-to-Edge sem sobreposição das barras do sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicialização dos botões
        btnVoltar = findViewById(R.id.btnVoltar);
        btnProximo = findViewById(R.id.btnProximo);

        // Botão Voltar: Fecha esta tela e retorna à anterior
        btnVoltar.setOnClickListener(v -> finish());

        // Botão Próximo: Navega para a Activity de Fotossíntese
        btnProximo.setOnClickListener(v -> {
            Intent intent = new Intent(this, FOTOSSINTESEActivity.class);
            startActivity(intent);
        });
    }
}
