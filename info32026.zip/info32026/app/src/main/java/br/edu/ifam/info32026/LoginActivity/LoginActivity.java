package br.edu.ifam.info32026.LoginActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.Executors;

import br.edu.ifam.info32026.AppDatabase;
import br.edu.ifam.info32026.MainActivity;
import br.edu.ifam.info32026.R;
import br.edu.ifam.info32026.model.Usuario;
import br.edu.ifam.info32026.model.UsuarioDao;

public class LoginActivity extends AppCompatActivity {
    private EditText edit_email;
    private EditText edit_senha;
    private Button button_login;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // Inicializa a instância do Room Database
        db = AppDatabase.getInstance(this);

        inicialmente();
        button_login.setOnClickListener(view -> Login());
    }

    private void Login() {
        String email = edit_email.getText().toString().trim();
        String senha = edit_senha.getText().toString().trim();

        if (!email.isEmpty()) {
            if (!senha.isEmpty()) {
                validaLogin(email, senha);
            } else {
                edit_senha.requestFocus();
                edit_senha.setError("Informe sua senha corretamente");
            }
        } else {
            edit_email.requestFocus();
            edit_email.setError("Informe seu email corretamente");
        }
    }

    private void validaLogin(String email, String senha) {
        // As consultas do Room DEVEM ser executadas fora da UI Thread
        Executors.newSingleThreadExecutor().execute(() -> {
            UsuarioDao usuarioDao = db.usuarioDao();
            Usuario user = usuarioDao.login(email, senha);

            // Voltar para a UI Thread para atualizar a interface (Toast / Intent)
            runOnUiThread(() -> {
                if (user != null) {
                    finish();
                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                } else {
                    Toast.makeText(LoginActivity.this, "E-mail ou senha incorretos", Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    private void inicialmente() {
        edit_email = findViewById(R.id.edit_text_id);
        edit_senha = findViewById(R.id.open_search_view_edit_text);
        button_login = findViewById(R.id.confirm_button);
    }
}
