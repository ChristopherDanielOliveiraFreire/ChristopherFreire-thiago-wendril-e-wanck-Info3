package br.edu.ifam.info32026;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class BotanicaQuizActivity2 extends AppCompatActivity {

    // Declaração dos componentes da interface
    private ImageButton btnOptionA, btnOptionB, btnOptionC;
    private TextView tvOptionA, tvOptionB, tvOptionC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_botanica_quiz2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Mapeamento dos componentes com os IDs do XML atualizado
        btnOptionA = findViewById(R.id.btnOptionA);
        btnOptionB = findViewById(R.id.btnOptionB);
        btnOptionC = findViewById(R.id.btnOptionC);

        tvOptionA = findViewById(R.id.tvOptionA);
        tvOptionB = findViewById(R.id.tvOptionB);
        tvOptionC = findViewById(R.id.tvOptionC);

        // Configuração dos cliques para cada opção
        setupOptionListeners();
    }

    private void setupOptionListeners() {
        // Alternativa A - Falsa
        View.OnClickListener listenerOptionA = v -> checkAnswer(false, tvOptionA);
        btnOptionA.setOnClickListener(listenerOptionA);
        tvOptionA.setOnClickListener(listenerOptionA);

        // Alternativa B - Falsa
        View.OnClickListener listenerOptionB = v -> checkAnswer(false, tvOptionB);
        btnOptionB.setOnClickListener(listenerOptionB);
        tvOptionB.setOnClickListener(listenerOptionB);

        // Alternativa C - Verdadeira (Correta)
        View.OnClickListener listenerOptionC = v -> checkAnswer(true, tvOptionC);
        btnOptionC.setOnClickListener(listenerOptionC);
        tvOptionC.setOnClickListener(listenerOptionC);
    }

    private void checkAnswer(boolean isCorrect, TextView selectedTextView) {
        if (isCorrect) {
            Toast.makeText(this, "Resposta Correta! (Verdadeiro)", Toast.LENGTH_SHORT).show();
            selectedTextView.setBackgroundColor(Color.parseColor("#4CAF50")); // Verde
            selectedTextView.setTextColor(Color.WHITE);
            disableAllOptions();
        } else {
            Toast.makeText(this, "Resposta Incorreta! (Falso)", Toast.LENGTH_SHORT).show();
            selectedTextView.setBackgroundColor(Color.parseColor("#F44336")); // Vermelho
            selectedTextView.setTextColor(Color.WHITE);
        }
    }

    private void disableAllOptions() {
        btnOptionA.setEnabled(false);
        btnOptionB.setEnabled(false);
        btnOptionC.setEnabled(false);
        tvOptionA.setEnabled(false);
        tvOptionB.setEnabled(false);
        tvOptionC.setEnabled(false);
    }
}
