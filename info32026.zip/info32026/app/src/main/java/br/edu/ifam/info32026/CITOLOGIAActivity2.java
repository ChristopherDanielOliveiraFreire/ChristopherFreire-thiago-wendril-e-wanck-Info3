package br.edu.ifam.info32026;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class CITOLOGIAActivity2 extends AppCompatActivity {

    private Button buttonVoltar;
    private Button buttonProximo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_citologiaactivity2);

        inicializarComponentes();

        // Ação do botão VOLTAR: fecha a tela atual
        buttonVoltar.setOnClickListener(view -> finish());

        // Ação do botão PRÓXIMO: navega para a próxima Activity (exemplo: CitologiaActivity3)
        buttonProximo.setOnClickListener(view ->{
            // Substitua 'ProximaActivity.class' pelo nome correto da sua próxima tela
            // Intent intent = new Intent(this, BotanicaActivity2.class);
            // startActivity(intent);
        });
    }

    private void inicializarComponentes() {
        buttonVoltar = findViewById(R.id.button6);
        buttonProximo = findViewById(R.id.button10);
    }
}